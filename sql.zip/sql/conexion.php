<?php

//Sitio conexion
const DB_Str = "mysql:host=localhost;dbname=tecnopre_pntm;charset=utf8mb4";
const DB_USER = "tecnopre_rootbd";
const DB_PASS = "2020*tecnopresta";

const Email = "tecnopresta@mep.go.cr";
const Email_PASS = "tPrest@1977";
//const Email_PASS = "Coqueta2020";

//Mauricio conexion
//const DB_Str = "mysql:host=localhost;dbname=pntm";
//const DB_USER = "root";
//const DB_PASS = "";

//Sandro conexion
//const DB_Str = "mysql:host=localhost;dbname=pntm";
//const DB_USER = "root";
//const DB_PASS = "basededatos"; 

?>
